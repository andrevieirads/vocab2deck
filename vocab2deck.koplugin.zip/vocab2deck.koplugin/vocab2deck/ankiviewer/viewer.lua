--[[--
Anki Viewer 1.4.0 embutido no vocab2deck: a tela de estudo (Show answer,
Again/Hard/Good/Easy, Delete, toque no cartão para o texto inteiro), a
importação de .apkg e as opções de estudo são as do Anki Viewer. Copiado de
ankiviewer.koplugin/main.lua.

Mudanças em relação ao original (para viver dentro deste plugin):
* os require apontam para vocab2deck/ankiviewer/db e vocab2deck/ankiviewer/apkg_import
  (nomes próprios, para não misturar com um ankiviewer.koplugin instalado);
* init não registra a entrada "Anki Viewer" no menu: quem abre a tela de estudo
  é o vocab2deck (lista de baralhos no Início, Estudar, gesto "estudar");
* a barra de cima da tela de estudo é só "‹ Voltar | Fechar" (Voltar volta ao
  Início, Fechar fecha o plugin). Decks, Settings e Import saíram dela: a lista
  de baralhos e o Importar ficam no Início, as opções nas Configurações;
* no fim do arquivo, funções para o vocab2deck chamar (openDeck, deleteDeck,
  openDeckFieldMapping) e o aviso decksChanged depois de importar.
showDeckSelection e showSettingsMenu continuam aqui, sem uso.
Banco, pasta shared e configurações continuam os mesmos do Anki Viewer
(<dados>/ankiviewer/ankiviewer.sqlite3, settings/ankiviewer.lua,
ankiviewer_mappings, ankiviewer_inspect_cache): o progresso de quem já
estudava no Anki Viewer é mantido.
--]]

local Blitbuffer = require("ffi/blitbuffer")
local ButtonTable = require("ui/widget/buttontable")
local Button = require("ui/widget/button")
local ButtonDialog = require("ui/widget/buttondialog")
local Device = require("device")
local Font = require("ui/font")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local Size = require("ui/size")
local TextWidget = require("ui/widget/textwidget")
local TextBoxWidget = require("ui/widget/textboxwidget")
local UIManager = require("ui/uimanager")
local VerticalGroup = require("ui/widget/verticalgroup")
local VerticalSpan = require("ui/widget/verticalspan")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan = require("ui/widget/horizontalspan")
local CenterContainer = require("ui/widget/container/centercontainer")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local InputContainer = require("ui/widget/container/inputcontainer")
local InfoMessage = require("ui/widget/infomessage")
local ConfirmBox = require("ui/widget/confirmbox")
local Menu = require("ui/widget/menu")
local InputDialog = require("ui/widget/inputdialog")
local NetworkMgr = require("ui/network/manager")
local LuaSettings = require("luasettings")
local CheckButton = require("ui/widget/checkbutton")
local ScrollableContainer = require("ui/widget/container/scrollablecontainer")
local GestureRange = require("ui/gesturerange")
local _ = require("gettext")
local logger = require("logger")
local DataStorage = require("datastorage")
local AnkiDB = require("vocab2deck/ankiviewer/db")
local AnkiApkgImport = require("vocab2deck/ankiviewer/apkg_import")

local VERTICAL_SPAN_SMALL = rawget(Size.span, "vertical_small") or rawget(Size.span, "vertical_default") or rawget(Size.span, "vertical_large") or 0

local AnkiViewerScreen = InputContainer:extend{}
local AnkiViewerStudyScreen = InputContainer:extend{}
local AnkiViewer = WidgetContainer:extend{
    name = "ankiviewer",
    is_doc_only = false,
}

local FIELD_MAPPING_SETTINGS = LuaSettings:open("ankiviewer_mappings")
local INSPECT_CACHE_SETTINGS = LuaSettings:open("ankiviewer_inspect_cache")

local function loadAllFieldMappings()
    local mappings = FIELD_MAPPING_SETTINGS:readSetting("mappings")
    if type(mappings) ~= "table" then
        mappings = {}
    end
    return mappings
end

local function formatDeckTitle(name)
    if type(name) ~= "string" or name == "" then
        return name
    end
    -- Replace runs of underscores with single spaces for better wrapping.
    local display = name:gsub("_+", " ")
    -- Hard cap very long titles so they do not dominate the header.
    if #display > 60 then
        display = display:sub(1, 57) .. "..."
    end
    return display
end

local function saveAllFieldMappings(mappings)
    if type(mappings) ~= "table" then
        mappings = {}
    end
    FIELD_MAPPING_SETTINGS:saveSetting("mappings", mappings)
    FIELD_MAPPING_SETTINGS:flush()
end

local function loadAllInspectInfo()
    local cache = INSPECT_CACHE_SETTINGS:readSetting("inspect")
    if type(cache) ~= "table" then
        cache = {}
    end
    return cache
end

local function saveAllInspectInfo(cache)
    if type(cache) ~= "table" then
        cache = {}
    end
    INSPECT_CACHE_SETTINGS:saveSetting("inspect", cache)
    INSPECT_CACHE_SETTINGS:flush()
end

local function loadInspectInfoForKey(key)
    if not key or key == "" then
        return nil
    end
    local cache = loadAllInspectInfo()
    return cache[key]
end

local function saveInspectInfoForKey(key, inspect_info)
    if not key or key == "" or type(inspect_info) ~= "table" then
        return
    end
    local cache = loadAllInspectInfo()
    cache[key] = inspect_info
    saveAllInspectInfo(cache)
end

local function clearDeckMetadataForShortName(short_name)
    if not short_name or short_name == "" then
        return
    end
    local mappings = loadAllFieldMappings()
    if mappings[short_name] then
        mappings[short_name] = nil
        saveAllFieldMappings(mappings)
    end
    local cache = loadAllInspectInfo()
    if cache[short_name] then
        cache[short_name] = nil
        saveAllInspectInfo(cache)
    end
end

local function loadFieldMappingForShortName(short_name)
    if not short_name or short_name == "" then
        return nil
    end
    local mappings = loadAllFieldMappings()
    return mappings[short_name]
end

local function saveFieldMappingForShortName(short_name, mapping)
    if not short_name or short_name == "" or type(mapping) ~= "table" then
        return
    end
    local models = mapping.models
    if type(models) ~= "table" or next(models) == nil then
        return
    end
    local mappings = loadAllFieldMappings()
    mappings[short_name] = mapping
    saveAllFieldMappings(mappings)
end

local function findApkgFileByShortName(short_name)
    if not short_name or short_name == "" then
        return nil
    end
    local files = AnkiApkgImport.listApkgFiles()
    if not files or #files == 0 then
        return nil
    end
    local target_lower = short_name:lower()
    local target_norm = target_lower:gsub("[_%s]+", "")
    local fuzzy_match = nil
    for _, file in ipairs(files) do
        local name = file.name or ""
        local base = name
        local dot = name:match("^.*()%.")
        if dot then
            base = name:sub(1, dot - 1)
        end
        local base_lower = base:lower()
        if base_lower == target_lower then
            return file
        end
        -- Fuzzy match: ignore underscores vs spaces and minor
        -- differences in formatting. Keep the first fuzzy match as
        -- fallback if there is no exact match.
        if not fuzzy_match then
            local base_norm = base_lower:gsub("[_%s]+", "")
            if base_norm == target_norm then
                fuzzy_match = file
            end
        end
    end
    return fuzzy_match
end

function AnkiViewerScreen:init()
    local Screen = Device.screen
    self.dimen = Geom:new{ x = 0, y = 0, w = Screen:getWidth(), h = Screen:getHeight() }
    self.covers_fullscreen = true
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end
    local title = TextWidget:new{
        face = Font:getFace("tfont"),
        text = _("Anki Viewer"),
    }
    local info = TextWidget:new{
        face = Font:getFace("smallinfofont"),
        text = _("Study Anki-style flashcards on your device using locally imported Anki decks."),
    }

    local button_row = ButtonTable:new{
        shrink_unneeded_width = true,
        width = math.floor(Screen:getWidth() * 0.8),
        buttons = {
            {
                {
                    text = _("Local study"),
                    callback = function()
                        self:openLocalStudy()
                    end,
                },
                {
                    text = _("Close"),
                    callback = function()
                        self:onClose()
                    end,
                },
            },
        },
    }

    local frame = FrameContainer:new{
        padding = Size.padding.large,
        margin = Size.margin.default,
        title,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        info,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        button_row,
    }

    self.layout = VerticalGroup:new{
        align = "center",
        VerticalSpan:new{ width = Size.span.vertical_large },
        frame,
    }
    self[1] = self.layout

    UIManager:setDirty(self, function()
        return "ui", self.dimen
    end)
end

function AnkiViewerScreen:openLocalStudy()
    if not self.plugin then
        return
    end
    self.plugin:openLocalStudyFromHome(self)
end

function AnkiViewerScreen:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    if self.plugin then
        self.plugin:onScreenClosed()
    end
end

function AnkiViewerStudyScreen:updateRatingLabels(previews)
    local function set_interval(widget, key)
        if not widget then
            return
        end
        local label = ""
        if previews and previews[key] and type(previews[key].label) == "string" and previews[key].label ~= "" then
            label = previews[key].label
        else
            if key == "again" then
                label = "<1m"
            elseif key == "hard" then
                label = "<6m"
            elseif key == "good" then
                label = "<10m"
            elseif key == "easy" then
                label = "4d"
            end
        end
        widget:setText(label)
    end

    set_interval(self.interval_again, "again")
    set_interval(self.interval_hard, "hard")
    set_interval(self.interval_good, "good")
    set_interval(self.interval_easy, "easy")
end

function AnkiViewerScreen:paintTo(bb, x, y)
    self.dimen.x = x
    self.dimen.y = y
    bb:paintRect(x, y, self.dimen.w, self.dimen.h, Blitbuffer.COLOR_WHITE)
    local content_size = self.layout:getSize()
    local offset_x = x + math.floor((self.dimen.w - content_size.w) / 2)
    local offset_y = y + math.floor((self.dimen.h - content_size.h) / 2)
    self.layout:paintTo(bb, offset_x, offset_y)
end

function AnkiViewerStudyScreen:init()
    local Screen = Device.screen
    self.dimen = Geom:new{ x = 0, y = 0, w = Screen:getWidth(), h = Screen:getHeight() }
    self.covers_fullscreen = true
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    local default_id = AnkiDB.ensureSampleData()
    -- last_deck_id may have been stored as string; coerce to number so it
    -- matches numeric deck IDs returned by AnkiDB.listDecks().
    local last_id = tonumber(self.plugin:readSetting("last_deck_id"))
    local decks = AnkiDB.listDecks()
    local selected_id = nil
    local selected_name = _("Default deck")
    if decks and #decks > 0 then
        -- First, try to find the last used deck
        if last_id then
            for _, d in ipairs(decks) do
                if d.id == last_id then
                    selected_id = d.id
                    selected_name = d.name or selected_name
                    break
                end
            end
        end
        -- If last deck not found, use the first available deck
        if not selected_id and decks[1] then
            selected_id = decks[1].id
            selected_name = decks[1].name or selected_name
        end
    end
    -- Fallback to default if no decks exist
    if not selected_id then
        selected_id = default_id
    end

    self.deck_id = selected_id
    self.deck_name = selected_name -- internal/raw name
    self.deck_title = formatDeckTitle(selected_name) -- display name
    self.current_card = nil
    self.showing_back = false

    local fullscreen_mode = false
    if self.plugin then
        fullscreen_mode = not not self.plugin:readSetting("fullscreen_study", false)
    end

    local card_width, card_height
    local top_bottom_spacing
    local frame_extras = Size.padding.fullscreen + Size.margin.default + Size.border.window
    if fullscreen_mode then
        card_width = Screen:getWidth() - (frame_extras * 2)
        top_bottom_spacing = Size.padding.small
        card_height = Screen:getHeight() - Size.item.height_large * 3.5 - (top_bottom_spacing * 2) - (frame_extras * 2)
    else
        card_width = math.floor(Screen:getWidth() * 0.85)
        card_height = Size.item.height_large * 8
        top_bottom_spacing = VERTICAL_SPAN_SMALL
    end
    self.fullscreen_top_bottom_spacing = top_bottom_spacing

    local title_max_width = math.floor(Screen:getWidth() * 0.9)
    local title_face = Font:getFace("cfont", 26)
    local title_line_height_px = math.floor((1 + 0.3) * title_face.size)
    local title_height = title_line_height_px * 2
    self.title_widget = TextBoxWidget:new{
        face = title_face,
        text = self.deck_title,
        width = title_max_width,
        height = title_height,
        height_adjust = true,
        height_overflow_show_ellipsis = true,
        alignment = "center",
    }
    local card_inner_width = card_width - (Size.margin.default * 2 + Size.padding.fullscreen * 2 + Size.border.window * 2)
    local card_inner_height = card_height - (Size.margin.default * 2 + Size.padding.fullscreen * 2 + Size.border.window * 2)
    self.card_widget = TextBoxWidget:new{
        face = Font:getFace("cfont"),
        text = "",
        width = card_inner_width,
        height = card_inner_height,
        alignment = "center",
        -- If the content is still too tall, show ellipsis instead of
        -- overflowing outside the card frame.
        height_overflow_show_ellipsis = true,
    }
    self.status_widget = TextWidget:new{
        face = Font:getFace("smallinfofont"),
        text = "",
    }

    self.interval_widget = TextWidget:new{
        face = Font:getFace("smallinfofont"),
        text = "",
    }

    -- Card container to give more space around the text and enforce a minimum width
    self.card_container = CenterContainer:new{
        dimen = Geom:new{ x = 0, y = 0, w = card_width, h = card_height },
        self.card_widget,
    }

    -- Card frame to visually emphasize question/answer
    local card_frame_inner = FrameContainer:new{
        padding = Size.padding.fullscreen,
        margin = Size.margin.default,
        radius = Size.radius.window,
        bordersize = Size.border.window,
        self.card_container,
    }
    local frame_total_width = card_width + (frame_extras * 2)
    local frame_total_height = card_height + (frame_extras * 2)
    self.card_frame = InputContainer:new{
        card_frame_inner,
        dimen = Geom:new{ w = frame_total_width, h = frame_total_height },
    }
    if Device:isTouchDevice() then
        self.card_frame.ges_events = {
            Tap = {
                GestureRange:new{
                    ges = "tap",
                    range = function() return self.card_frame.dimen end,
                },
            },
        }
        self.card_frame.onTap = function() self:showFullText() end
    end

    -- Top controls row. Embutido no vocab2deck: só "Voltar | Fechar" (Decks,
    -- Settings e Import ficam no Início e nas Configurações do vocab2deck).
    -- Voltar volta para o Início; Fechar fecha o plugin.
    self.close_button = Button:new{
        text = _("Fechar"),
        callback = function()
            self:onClose()
            if self.plugin and self.plugin.on_close_all then
                self.plugin.on_close_all()
            end
        end,
        text_font_face = "cfont",
        text_font_size = 24,
        text_font_bold = false,
        bordersize = 0,
        margin = 0,
        radius = 0,
    }

    self.back_button = Button:new{
        text = _("‹ Voltar"),
        callback = function()
            self:onClose()
            if self.plugin and self.plugin.on_back then
                self.plugin.on_back()
            end
        end,
        text_font_face = "cfont",
        text_font_size = 24,
        text_font_bold = false,
        bordersize = 0,
        margin = 0,
        radius = 0,
    }

    local top_controls = HorizontalGroup:new{
        align = "center",
        self.back_button,
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        TextWidget:new{
            face = Font:getFace("cfont", 22),
            text = "|",
        },
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        self.close_button,
    }

    local top_bar = VerticalGroup:new{
        align = "center",
        top_controls,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.title_widget,
    }

    -- Row used when showing the front side (only Show answer)
    local show_row = ButtonTable:new{
        shrink_unneeded_width = true,
        width = math.floor(Screen:getWidth() * 0.85),
        buttons = {
            {
                {
                    id = "show_button",
                    text = _("Show answer"),
                    callback = function()
                        self:onShowOrNext()
                    end,
                },
            },
        },
    }
    self.show_button = show_row:getButtonById("show_button")

    -- Interval labels (non-interactive) for each rating, slightly smaller than smallinfofont
    local small_interval_size = math.floor(Font.sizemap.smallinfofont * 0.85)
    local small_interval_face = Font:getFace("smallinfofont", small_interval_size)
    self.interval_again = TextWidget:new{
        face = small_interval_face,
        text = "",
    }
    self.interval_hard = TextWidget:new{
        face = small_interval_face,
        text = "",
    }
    self.interval_good = TextWidget:new{
        face = small_interval_face,
        text = "",
    }
    self.interval_easy = TextWidget:new{
        face = small_interval_face,
        text = "",
    }

    -- Rating buttons, one column per rating (interval label above, button below)
    local btn_width = math.floor(Screen:getWidth() * 0.18)
    self.delete_button = Button:new{
        text = _("Delete"),
        callback = function() self:onDeleteCard() end,
        width = btn_width, bordersize = 0, margin = 0, radius = 0,
    }
    self.again_button = Button:new{
        text = _("Again"),
        callback = function() self:onRate("again") end,
        width = btn_width, bordersize = 0, margin = 0, radius = 0,
    }
    self.hard_button = Button:new{
        text = _("Hard"),
        callback = function() self:onRate("hard") end,
        width = btn_width, bordersize = 0, margin = 0, radius = 0,
    }
    self.good_button = Button:new{
        text = _("Good"),
        callback = function() self:onRate("good") end,
        width = btn_width, bordersize = 0, margin = 0, radius = 0,
    }
    self.easy_button = Button:new{
        text = _("Easy"),
        callback = function() self:onRate("easy") end,
        width = btn_width, bordersize = 0, margin = 0, radius = 0,
    }

    local col_delete_inner = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = btn_width, h = small_interval_face.size },
            TextWidget:new{ face = small_interval_face, text = "" },
        },
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.delete_button,
    }
    local col_delete = InputContainer:new{
        col_delete_inner,
        dimen = Geom:new{ w = btn_width, h = col_delete_inner:getSize().h },
    }
    col_delete.ges_events = {
        Tap = {
            GestureRange:new{
                ges = "tap",
                range = function() return col_delete.dimen end,
            },
        },
    }
    col_delete.onTap = function() self:onDeleteCard() end

    local col_again_inner = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = btn_width, h = small_interval_face.size },
            self.interval_again,
        },
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.again_button,
    }
    local col_again = InputContainer:new{
        col_again_inner,
        dimen = Geom:new{ w = btn_width, h = col_again_inner:getSize().h },
    }
    col_again.ges_events = {
        Tap = {
            GestureRange:new{
                ges = "tap",
                range = function() return col_again.dimen end,
            },
        },
    }
    col_again.onTap = function() self:onRate("again") end

    local col_hard_inner = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = btn_width, h = small_interval_face.size },
            self.interval_hard,
        },
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.hard_button,
    }
    local col_hard = InputContainer:new{
        col_hard_inner,
        dimen = Geom:new{ w = btn_width, h = col_hard_inner:getSize().h },
    }
    col_hard.ges_events = {
        Tap = {
            GestureRange:new{
                ges = "tap",
                range = function() return col_hard.dimen end,
            },
        },
    }
    col_hard.onTap = function() self:onRate("hard") end

    local col_good_inner = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = btn_width, h = small_interval_face.size },
            self.interval_good,
        },
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.good_button,
    }
    local col_good = InputContainer:new{
        col_good_inner,
        dimen = Geom:new{ w = btn_width, h = col_good_inner:getSize().h },
    }
    col_good.ges_events = {
        Tap = {
            GestureRange:new{
                ges = "tap",
                range = function() return col_good.dimen end,
            },
        },
    }
    col_good.onTap = function() self:onRate("good") end

    local col_easy_inner = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = btn_width, h = small_interval_face.size },
            self.interval_easy,
        },
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.easy_button,
    }
    local col_easy = InputContainer:new{
        col_easy_inner,
        dimen = Geom:new{ w = btn_width, h = col_easy_inner:getSize().h },
    }
    col_easy.ges_events = {
        Tap = {
            GestureRange:new{
                ges = "tap",
                range = function() return col_easy.dimen end,
            },
        },
    }
    col_easy.onTap = function() self:onRate("easy") end

    local rating_row = HorizontalGroup:new{
        align = "center",
        col_again,
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        col_hard,
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        col_good,
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        col_easy,
        HorizontalSpan:new{ width = Size.span.horizontal_small },
        col_delete,
    }

    -- Separate layouts for front (question) and back (answer + ratings)
    self.front_layout = VerticalGroup:new{
        align = "center",
        VerticalSpan:new{ width = self.fullscreen_top_bottom_spacing },
        top_bar,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.card_frame,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        show_row,
        VerticalSpan:new{ width = self.fullscreen_top_bottom_spacing },
    }

    self.back_layout = VerticalGroup:new{
        align = "center",
        VerticalSpan:new{ width = self.fullscreen_top_bottom_spacing },
        top_bar,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        self.card_frame,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        rating_row,
        VerticalSpan:new{ width = self.fullscreen_top_bottom_spacing },
    }

    self.active_layout = self.front_layout
    self[1] = self.front_layout

    self:setRatingButtonsEnabled(false)
    self:setShowButtonVisible(true)
    self:loadNextCard()

    UIManager:setDirty(self, function()
        return "ui", self.dimen
    end)
end

function AnkiViewerStudyScreen:setStatus(text)
    self.status_widget:setText(text or "")
end

function AnkiViewerStudyScreen:setRatingButtonsEnabled(enabled)
    local flag = not not enabled
    if self.again_button then self.again_button:enableDisable(flag) end
    if self.hard_button then self.hard_button:enableDisable(flag) end
    if self.good_button then self.good_button:enableDisable(flag) end
    if self.easy_button then self.easy_button:enableDisable(flag) end
end

function AnkiViewerStudyScreen:setShowButtonVisible(visible)
    if not self.show_button then
        return
    end
    if visible then
        self.show_button:enableDisable(true)
        self.show_button:setText(_("Show answer"))
    else
        self.show_button:enableDisable(false)
        self.show_button:setText("")
    end
end

function AnkiViewerStudyScreen:loadNextCard()
    local randomize_equal_due = false
    local daily_new_limit = 20
    if self.plugin then
        randomize_equal_due = not not self.plugin:readSetting("randomize_equal_due", false)
        daily_new_limit = tonumber(self.plugin:readSetting("daily_new_cards_limit", 20)) or 20
    end
    local card = AnkiDB.fetchNextDueCard(self.deck_id, nil, randomize_equal_due, daily_new_limit)
    if not card then
        self.current_card = nil
        self.showing_back = false
        self.card_full_text = nil
        self.card_widget:setText(_("No cards due."))
        self:setShowButtonVisible(false)
        self:setRatingButtonsEnabled(false)
        self.active_layout = self.front_layout
        self[1] = self.front_layout
        self:refresh()
        return
    end
    self.current_card = card
    self.showing_back = false
    self.card_full_text = card.front
    self.card_widget:setText(card.front)
    self:setShowButtonVisible(true)
    self:setRatingButtonsEnabled(false)
    self.active_layout = self.front_layout
    self[1] = self.front_layout
    self:refresh()
end

function AnkiViewerStudyScreen:onShowOrNext()
    if not self.current_card then
        self:loadNextCard()
        return
    end
    if not self.showing_back then
        self.showing_back = true
        self.card_full_text = self.current_card.back
        self.card_widget:setText(self.current_card.back)
        local min_interval_days = self.plugin and tonumber(self.plugin:readSetting("min_interval_days", 0)) or 0
        local previews = AnkiDB.previewIntervals(self.current_card, nil, min_interval_days)
        self:updateRatingLabels(previews)
        self:setShowButtonVisible(false)
        self:setRatingButtonsEnabled(true)
        self.active_layout = self.back_layout
        self[1] = self.back_layout
        self:refresh()
    end
end

function AnkiViewerStudyScreen:onRate(rating)
    if not self.current_card then
        return
    end
    local min_interval_days = self.plugin and tonumber(self.plugin:readSetting("min_interval_days", 0)) or 0
    local is_new_card = (self.current_card.reps == 0 and self.current_card.interval == 0)
    local updated = AnkiDB.updateCardScheduling(self.current_card, rating, nil, min_interval_days)
    if is_new_card and self.deck_id then
        AnkiDB.incrementDailyNewCardsCount(self.deck_id)
    end
    self.current_card = updated or self.current_card
    self.showing_back = false
    self:loadNextCard()
end

function AnkiViewerStudyScreen:showFullText()
    if not self.card_full_text or self.card_full_text == "" then
        return
    end
    local TextViewer = require("ui/widget/textviewer")
    local text_viewer = TextViewer:new{
        title = _("Full Text"),
        text = self.card_full_text,
    }
    UIManager:show(text_viewer)
end

function AnkiViewerStudyScreen:onDeleteCard()
    if not self.current_card then
        return
    end
    local card = self.current_card
    UIManager:show(ConfirmBox:new{
        text = _("Delete this card?"),
        ok_text = _("Delete"),
        cancel_text = _("Cancel"),
        ok_callback = function()
            AnkiDB.deleteCard(card.id)
            self.current_card = nil
            self.showing_back = false
            self:loadNextCard()
        end,
    })
end

function AnkiViewerStudyScreen:showSettingsMenu()
    local study = self
    local screen = Device.screen
    local menu

    local items = {
        {
            text = _("Randomize cards with same due"),
            keep_menu_open = true,
            mandatory_func = function()
                if not study.plugin then
                    return "OFF"
                end
                if study.plugin:readSetting("randomize_equal_due", false) then
                    return "ON"
                end
                return "OFF"
            end,
            checked_func = function()
                if not study.plugin then
                    return false
                end
                return not not study.plugin:readSetting("randomize_equal_due", false)
            end,
            callback = function()
                if not study.plugin then
                    return
                end
                local current = not not study.plugin:readSetting("randomize_equal_due", false)
                study.plugin:saveSetting("randomize_equal_due", not current)
                if menu and menu.updateItems then
                    menu:updateItems(1, true)
                end
            end,
        },
        {
            text = _("Daily new cards limit"),
            keep_menu_open = true,
            mandatory_func = function()
                if not study.plugin then
                    return "20"
                end
                local limit = tonumber(study.plugin:readSetting("daily_new_cards_limit", 20))
                if limit == 0 then
                    return _("Unlimited")
                end
                return tostring(limit)
            end,
            callback = function()
                if not study.plugin then
                    return
                end
                local current_limit = tonumber(study.plugin:readSetting("daily_new_cards_limit", 20))
                local input_dialog
                input_dialog = InputDialog:new{
                    title = _("Daily new cards limit"),
                    input = tostring(current_limit),
                    input_type = "number",
                    description = _("Set the maximum number of new cards to show per day. Set to 0 for unlimited."),
                    buttons = {
                        {
                            {
                                text = _("Cancel"),
                                callback = function()
                                    UIManager:close(input_dialog)
                                end,
                            },
                            {
                                text = _("Save"),
                                is_enter_default = true,
                                callback = function()
                                    local new_limit = tonumber(input_dialog:getInputText()) or 20
                                    if new_limit < 0 then
                                        new_limit = 0
                                    end
                                    study.plugin:saveSetting("daily_new_cards_limit", new_limit)
                                    UIManager:close(input_dialog)
                                    if menu and menu.updateItems then
                                        menu:updateItems(2, true)
                                    end
                                end,
                            },
                        },
                    },
                }
                UIManager:show(input_dialog)
                input_dialog:onShowKeyboard()
            end,
        },
        {
            text = _("Fullscreen study mode"),
            keep_menu_open = true,
            mandatory_func = function()
                if not study.plugin then
                    return "OFF"
                end
                if study.plugin:readSetting("fullscreen_study", false) then
                    return "ON"
                end
                return "OFF"
            end,
            checked_func = function()
                if not study.plugin then
                    return false
                end
                return not not study.plugin:readSetting("fullscreen_study", false)
            end,
            callback = function()
                if not study.plugin then
                    return
                end
                local current = not not study.plugin:readSetting("fullscreen_study", false)
                study.plugin:saveSetting("fullscreen_study", not current)
                UIManager:show(InfoMessage:new{
                    text = _("Fullscreen mode will take effect on next study session."),
                    timeout = 3,
                })
                if menu and menu.updateItems then
                    menu:updateItems(3, true)
                end
            end,
        },
        {
            text = _("Minimum interval (days)"),
            keep_menu_open = true,
            mandatory_func = function()
                if not study.plugin then
                    return _("Default")
                end
                local val = tonumber(study.plugin:readSetting("min_interval_days", 0)) or 0
                if val == 0 then
                    return _("Default")
                end
                return tostring(val) .. "d"
            end,
            callback = function()
                if not study.plugin then
                    return
                end
                local options = {
                    { text = _("Default (no minimum)"), value = 0 },
                    { text = _("1 day"), value = 1 },
                    { text = _("3 days"), value = 3 },
                    { text = _("7 days"), value = 7 },
                    { text = _("14 days"), value = 14 },
                }
                local buttons = {}
                for i, opt in ipairs(options) do
                    table.insert(buttons, {
                        {
                            text = opt.text,
                            callback = function()
                                study.plugin:saveSetting("min_interval_days", opt.value)
                                UIManager:show(InfoMessage:new{
                                    text = _("Minimum interval updated."),
                                    timeout = 2,
                                })
                                if menu and menu.updateItems then
                                    menu:updateItems(4, true)
                                end
                            end,
                        },
                    })
                end
                UIManager:show(require("ui/widget/buttondialog"):new{
                    title = _("Set minimum interval"),
                    buttons = buttons,
                })
            end,
        },
        {
            text = _("Field mapping"),
            keep_menu_open = false,
            callback = function()
                if menu then
                    UIManager:close(menu)
                end
                if study.plugin and study.plugin.openCurrentDeckFieldMapping then
                    study.plugin:openCurrentDeckFieldMapping(study)
                end
            end,
        },
        {
            text = _("Close"),
            keep_menu_open = false,
            callback = function()
                if menu then
                    UIManager:close(menu)
                end
            end,
        },
    }

    menu = Menu:new{
        title = _("Settings"),
        item_table = items,
        covers_fullscreen = true,
        width = math.floor(screen:getWidth() * 0.9),
        height = math.floor(screen:getHeight() * 0.9),
    }

    function menu:onMenuChoice(item)
        if item.callback then
            item.callback()
        end
        if not item.keep_menu_open then
            UIManager:close(self)
        end
        return true
    end

    UIManager:show(menu)
end

function AnkiViewerStudyScreen:applyDeckSelection(deck)
    if not deck or not deck.id then
        return
    end
    self.deck_id = deck.id
    self.deck_name = deck.name or self.deck_name
    self.deck_title = formatDeckTitle(self.deck_name)
    if self.title_widget and self.title_widget.setText then
        self.title_widget:setText(self.deck_title)
    end
    if self.plugin then
        self.plugin:saveSetting("last_deck_id", self.deck_id)
    end
    self.current_card = nil
    self.showing_back = false
    self:loadNextCard()
end

function AnkiViewerStudyScreen:showDeckSelection()
    local decks = AnkiDB.listDecks()
    if not decks or #decks == 0 then
        local msg = InfoMessage:new{
            text = _("No decks available."),
            timeout = 4,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local study = self
    local items = {}
    for i, d in ipairs(decks) do
        local label = d.name or ("Deck " .. tostring(d.id or ""))
        if d.card_count and d.card_count > 0 then
            label = string.format("%s (%d)", label, d.card_count)
        end
        table.insert(items, {
            text = label,
            keep_menu_open = false,
            deck_id = d.id,
            deck_name = d.name,
            callback = function()
                study:applyDeckSelection(d)
            end,
        })
    end

    local screen = Device.screen
    local menu = Menu:new{
        title = _("Select deck"),
        item_table = items,
        covers_fullscreen = true,
        width = math.floor(screen:getWidth() * 0.9),
        height = math.floor(screen:getHeight() * 0.9),
    }

    function menu:onMenuChoice(item)
        if item.callback then
            item.callback()
        end
        UIManager:close(self)
        return true
    end

    function menu:onMenuHold(item)
        local deck_id = item and item.deck_id
        if not deck_id then
            return true
        end
        local deck_name = item.deck_name or item.text or ""
        UIManager:show(ConfirmBox:new{
            text = string.format(_("Delete deck \"%s\"?"), deck_name),
            ok_text = _("Delete"),
            cancel_text = _("Cancel"),
            ok_callback = function()
                local ok_call, result_or_err = pcall(AnkiDB.deleteDeck, deck_id)
                if not ok_call or not result_or_err then
                    local err_text = not ok_call and result_or_err or _("Delete failed")
                    local msg = InfoMessage:new{
                        text = _("Failed to delete deck: ") .. tostring(err_text or "Lua error"),
                        timeout = 6,
                        show_icon = true,
                    }
                    UIManager:show(msg)
                    return
                end

                if study.deck_id == deck_id then
                    local remaining = AnkiDB.listDecks()
                    local replacement = nil
                    for _, d in ipairs(remaining) do
                        if d.id ~= deck_id then
                            replacement = d
                            break
                        end
                    end
                    if replacement then
                        study:applyDeckSelection(replacement)
                    else
                        study.deck_id = nil
                        study.deck_name = study.deck_name or _("Default deck")
                        study.deck_title = formatDeckTitle(study.deck_name)
                        if study.title_widget and study.title_widget.setText then
                            study.title_widget:setText(study.deck_title)
                        end
                        study.current_card = nil
                        study.showing_back = false
                        study.card_widget:setText(_("No cards available."))
                        study:setShowButtonVisible(false)
                        study:setRatingButtonsEnabled(false)
                    end
                end

                clearDeckMetadataForShortName(deck_name)

                UIManager:close(menu)
            end,
        })
        return true
    end

    UIManager:show(menu)
end

function AnkiViewer:openCurrentDeckFieldMapping(study_screen)
    local loading = InfoMessage:new{
        text = _("Preparing field mapping…"),
        timeout = 0,
    }
    UIManager:show(loading)

    if not study_screen or not (study_screen.deck_name or study_screen.deck_title) then
        UIManager:close(loading)
        local msg = InfoMessage:new{
            text = _("No active deck to configure."),
            timeout = 4,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local deck_name = study_screen.deck_name or study_screen.deck_title
    local short_name = deck_name
    local existing_mapping = loadFieldMappingForShortName(short_name)

    local inspect_info
    local cache_key
    if existing_mapping and existing_mapping.short_name and existing_mapping.short_name ~= "" then
        cache_key = existing_mapping.short_name
        inspect_info = loadInspectInfoForKey(cache_key)
    end
    if not inspect_info then
        cache_key = short_name
        inspect_info = loadInspectInfoForKey(cache_key)
    end

    if inspect_info then
        UIManager:close(loading)
        local effective_short = inspect_info.short_name or cache_key or short_name
        existing_mapping = loadFieldMappingForShortName(effective_short)
        self:showApkgFieldMappingDialog(nil, inspect_info, existing_mapping, function(apply, mapping)
            if not apply then
                return
            end
            if mapping and effective_short and effective_short ~= "" then
                mapping.short_name = effective_short
                saveFieldMappingForShortName(effective_short, mapping)
                local msg = InfoMessage:new{
                    text = _("Field mapping saved for this deck."),
                    timeout = 4,
                    show_icon = true,
                }
                UIManager:show(msg)

                local deck_id = study_screen.deck_id
                local deck_title = study_screen.deck_name or effective_short
                if deck_id then
                    self:_reimportFromSourceNotes(deck_id, deck_title, mapping, nil)
                end
            else
                local msg = InfoMessage:new{
                    text = _("No changes to field mapping."),
                    timeout = 4,
                    show_icon = true,
                }
                UIManager:show(msg)
            end
        end)
        return
    end

    local file = findApkgFileByShortName(short_name)
    if not file and existing_mapping and existing_mapping.short_name and existing_mapping.short_name ~= "" then
        file = findApkgFileByShortName(existing_mapping.short_name)
    end

    if not file then
        UIManager:close(loading)
        local msg = InfoMessage:new{
            text = _("No matching .apkg file found for this deck."),
            timeout = 6,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local analyzing = InfoMessage:new{
        text = string.format(_("Analyzing %s…"), file.name or short_name),
        timeout = 0,
    }
    UIManager:close(loading)
    UIManager:show(analyzing)

    local ok_pcall, ok_inspect, inspect_payload = pcall(AnkiApkgImport.inspectApkg, file.path)
    UIManager:close(analyzing)

    if not ok_pcall then
        local msg = InfoMessage:new{
            text = _("Failed to analyze .apkg: ") .. tostring(ok_inspect or "Lua error"),
            timeout = 8,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    if not ok_inspect then
        local err_text = inspect_payload or "Unknown error"
        local msg = InfoMessage:new{
            text = _("Failed to analyze .apkg: ") .. tostring(err_text),
            timeout = 8,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local inspect_info2 = inspect_payload or {}
    local effective_short = inspect_info2.short_name or short_name
    saveInspectInfoForKey(effective_short, inspect_info2)
    existing_mapping = loadFieldMappingForShortName(effective_short)

    self:showApkgFieldMappingDialog(file, inspect_info2, existing_mapping, function(apply, mapping)
        if not apply then
            return
        end
        if mapping and effective_short and effective_short ~= "" then
            mapping.short_name = effective_short
            saveFieldMappingForShortName(effective_short, mapping)
            local msg = InfoMessage:new{
                text = _("Field mapping saved for this deck."),
                timeout = 4,
                show_icon = true,
            }
            UIManager:show(msg)

            local deck_id = study_screen.deck_id
            local deck_title = study_screen.deck_name or effective_short
            if deck_id then
                self:_reimportFromSourceNotes(deck_id, deck_title, mapping, file)
            else
                self:_chooseImportMode(effective_short, function(merge_opts)
                    self:_performApkgImport(file, mapping, merge_opts)
                end)
            end
        else
            local msg = InfoMessage:new{
                text = _("No changes to field mapping."),
                timeout = 4,
                show_icon = true,
            }
            UIManager:show(msg)
        end
    end)
end

-- Calls on_choice(merge_opts) once the user picked how to import a deck that
-- already exists (merge_opts is nil for replace); calls it right away with
-- nil when no deck with that name exists yet.
function AnkiViewer:_chooseImportMode(deck_name, on_choice)
    local exists = false
    local ok_decks, decks = pcall(AnkiDB.listDecks)
    if ok_decks and type(decks) == "table" then
        for _, deck in ipairs(decks) do
            if deck.name == deck_name then
                exists = true
                break
            end
        end
    end
    if not exists then
        on_choice(nil)
        return
    end

    local dialog
    local function choose(merge_opts)
        UIManager:close(dialog)
        on_choice(merge_opts)
    end
    dialog = ButtonDialog:new{
        title = string.format(_("Deck '%s' already exists."), deck_name),
        buttons = {
            {{
                text = _("Merge (keep progress)"),
                callback = function() choose({ merge = true }) end,
            }},
            {{
                text = _("Merge and remove cards not in file"),
                callback = function() choose({ merge = true, remove_missing = true }) end,
            }},
            {{
                text = _("Replace (reset progress)"),
                callback = function() choose(nil) end,
            }},
            {{
                text = _("Cancel"),
                callback = function() UIManager:close(dialog) end,
            }},
        },
    }
    UIManager:show(dialog)
end

function AnkiViewer:_performApkgImport(file, mapping, merge_opts)
    if not file or not file.path then
        return
    end

    local progress = InfoMessage:new{
        text = string.format(_("Importing %s…"), file.name or file.path),
        timeout = 0,
    }
    UIManager:show(progress)

    local ok_call, ok_import, payload = pcall(AnkiApkgImport.importApkg, file.path, mapping, merge_opts)
    UIManager:close(progress)

    local text
    if not ok_call then
        text = _("Failed to import .apkg: ") .. tostring(ok_import or "Lua error")
    else
        if ok_import and payload and type(payload) == "table" then
            local info = payload
            local deck_name = info.deck_name or file.name or _("Imported deck")
            local card_count = tonumber(info.card_count or 0) or 0
            local src_cards = tonumber(info.source_total_cards or 0) or 0
            local src_notes = tonumber(info.source_total_notes or 0) or 0
            local extracted = tonumber(info.extracted_cards or 0) or 0
            local stats = info.merge_stats
            if stats then
                text = string.format(_("Merged into deck '%s': %d new, %d kept, %d removed."), deck_name, stats.added, stats.kept, stats.removed)
            elseif card_count == 0 then
                text = string.format(_("Imported deck '%s' with %d cards (source cards: %d, notes: %d, extracted: %d)."), deck_name, card_count, src_cards, src_notes, extracted)
            else
                text = string.format(_("Imported deck '%s' with %d cards."), deck_name, card_count)
            end
        else
            local err_msg = payload or "Unknown error"
            text = _("Failed to import .apkg: ") .. tostring(err_msg)
        end
    end

    local msg = InfoMessage:new{
        text = text,
        timeout = 8,
        show_icon = true,
    }
    UIManager:show(msg)
    self:decksChanged() -- embutido: o Início atualiza a lista de baralhos
end

-- Changing the field mapping rebuilds the deck's cards; merging (matched by
-- note guid) keeps their review progress.
local REMAP_MERGE_OPTS = { merge = true, remove_missing = true }

function AnkiViewer:_reimportFromSourceNotes(deck_id, deck_name, mapping, file)
    if not deck_id or not mapping then
        if file then
            self:_performApkgImport(file, mapping, REMAP_MERGE_OPTS)
        end
        return
    end

    local progress = InfoMessage:new{
        text = _("Rebuilding deck from stored notes…"),
        timeout = 0,
    }
    UIManager:show(progress)

    local notes
    local ok_notes, notes_or_err = pcall(AnkiDB.loadSourceNotes, deck_id)
    if ok_notes then
        notes = notes_or_err
    else
        notes = nil
    end

    if not notes or #notes == 0 then
        UIManager:close(progress)
        if file then
            self:_performApkgImport(file, mapping, REMAP_MERGE_OPTS)
        else
            local msg = InfoMessage:new{
                text = _("No stored source notes are available for this deck; cannot rebuild cards."),
                timeout = 8,
                show_icon = true,
            }
            UIManager:show(msg)
        end
        return
    end

    local cards = AnkiApkgImport.buildCardsFromSourceNotes(notes, mapping)
    if not cards or #cards == 0 then
        UIManager:close(progress)
        local msg = InfoMessage:new{
            text = _("No cards were produced from stored notes with the current field selection. Try choosing different front/back fields."),
            timeout = 8,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local ok_db, imported_deck_id, count = pcall(AnkiDB.mergeDeckFromPairs, deck_name, cards, true)
    UIManager:close(progress)

    local text
    if not ok_db then
        text = _("Failed to import cards into local database.")
    else
        text = string.format(_("Rebuilt deck '%s' with %d cards from stored notes."), deck_name, count or 0)
    end

    local msg = InfoMessage:new{
        text = text,
        timeout = 8,
        show_icon = true,
    }
    UIManager:show(msg)
end

function AnkiViewer:showApkgFieldMappingDialog(file, inspect_info, existing_mapping, on_done)
    local models = (inspect_info and inspect_info.models) or {}
    if type(models) ~= "table" or next(models) == nil then
        if on_done then
            on_done(true, nil)
        end
        return
    end

    local Screen = Device.screen
    local screen_width = Screen:getWidth()
    local screen_height = Screen:getHeight()
    -- Inner content width slightly smaller than screen, used for wrapping text
    local dialog_width = math.floor(screen_width * 0.9)
    local dialog_height = math.floor(screen_height * 0.9)

    local title = TextBoxWidget:new{
        face = Font:getFace("x_smalltfont"),
        text = _("Select front and back fields"),
        width = dialog_width,
    }

    local subtitle_text = (file and file.name) or (inspect_info and inspect_info.short_name) or _("Deck")
    local subtitle = TextBoxWidget:new{
        face = Font:getFace("smallinfofont"),
        text = subtitle_text,
        width = dialog_width,
    }

    local description = TextBoxWidget:new{
        face = Font:getFace("smallinfofont"),
        text = _("Choose which note fields to use on the front and back of cards. You can select multiple fields."),
        width = dialog_width,
    }

    local content_group = VerticalGroup:new{
        align = "left",
    }

    local existing_models = existing_mapping and existing_mapping.models or nil
    local model_state = {}

    -- Determine a single primary model to keep the UI simple.
    -- We pick the model with the highest note_count that has fields;
    -- if note_count is not available, we fall back to the first model
    -- that has at least one field.
    local primary_mid
    local primary_model
    local max_note_count = -1
    for mid, model in pairs(models) do
        if type(model) == "table" and type(model.fields) == "table" and #model.fields > 0 then
            local note_count = tonumber(model.note_count or 0) or 0
            if note_count > max_note_count then
                max_note_count = note_count
                primary_mid = mid
                primary_model = model
            end
        end
    end
    if not primary_model then
        for mid, model in pairs(models) do
            if type(model) == "table" and type(model.fields) == "table" and #model.fields > 0 then
                primary_mid = mid
                primary_model = model
                break
            end
        end
    end

    local function buildSampleText(field_info)
        local samples = field_info.samples or {}
        if #samples == 0 then
            return ""
        end
        local sample = tostring(samples[1] or "")
        sample = sample:gsub("\n+", " ")
        if #sample > 120 then
            sample = sample:sub(1, 117) .. "..."
        end
        return sample
    end

    if primary_mid and primary_model then
        local saved = existing_models and existing_models[primary_mid] or nil
        local front_index_set = {}
        local back_index_set = {}
        if saved then
            if type(saved.front_indexes) == "table" then
                for _, idx in ipairs(saved.front_indexes) do
                    idx = tonumber(idx)
                    if idx then
                        front_index_set[idx] = true
                    end
                end
            end
            if type(saved.back_indexes) == "table" then
                for _, idx in ipairs(saved.back_indexes) do
                    idx = tonumber(idx)
                    if idx then
                        back_index_set[idx] = true
                    end
                end
            end
        else
            if primary_model.fields[1] then
                front_index_set[1] = true
            end
            if #primary_model.fields > 1 then
                for idx = 2, #primary_model.fields do
                    back_index_set[idx] = true
                end
            end
        end

        local state_for_model = {
            id = primary_mid,
            fields = {},
        }

        for i_field, field_info in ipairs(primary_model.fields) do
            local idx = tonumber(field_info.index or 0) or 0
            if idx > 0 then
                local field_name = field_info.name or tostring(idx)
                local sample_text = buildSampleText(field_info)
                local label_text
                if sample_text ~= "" then
                    label_text = string.format("%s (%s)", field_name, sample_text)
                else
                    label_text = field_name
                end

                local front_cb = CheckButton:new{
                    text = _("Front"),
                    checked = not not front_index_set[idx],
                    width = math.floor(dialog_width * 0.18),
                }
                local back_cb = CheckButton:new{
                    text = _("Back"),
                    checked = not not back_index_set[idx],
                    width = math.floor(dialog_width * 0.18),
                }

                local label_widget = TextBoxWidget:new{
                    face = Font:getFace("smallinfofont"),
                    text = label_text,
                    width = dialog_width - math.floor(dialog_width * 0.18) * 2 - Size.span.horizontal_small * 4,
                }

                local row = HorizontalGroup:new{
                    align = "top",
                    front_cb,
                    HorizontalSpan:new{ width = Size.span.horizontal_small },
                    back_cb,
                    HorizontalSpan:new{ width = Size.span.horizontal_small },
                    label_widget,
                }
                table.insert(content_group, row)

                state_for_model.fields[#state_for_model.fields + 1] = {
                    index = idx,
                    front_cb = front_cb,
                    back_cb = back_cb,
                }
            end
        end

        table.insert(content_group, VerticalSpan:new{ width = VERTICAL_SPAN_SMALL })
        model_state[primary_mid] = state_for_model
    end

    if next(model_state) == nil then
        if on_done then
            on_done(true, nil)
        end
        return
    end

    -- Forward declaration so button callbacks can close the dialog
    local dialog

    local buttons_row = ButtonTable:new{
        shrink_unneeded_width = true,
        width = dialog_width,
        buttons = {
            {
                {
                    text = _("Cancel"),
                    callback = function()
                        if dialog then
                            UIManager:close(dialog)
                        end
                        UIManager:setDirty(nil, "full")
                        if on_done then
                            on_done(false, nil)
                        end
                    end,
                },
                {
                    text = _("Import"),
                    callback = function()
                        local mapping = {
                            models = {},
                        }
                        for mid, state_for_model in pairs(model_state) do
                            local front_indexes = {}
                            local back_indexes = {}
                            for _, field_state in ipairs(state_for_model.fields) do
                                if field_state.front_cb.checked then
                                    table.insert(front_indexes, field_state.index)
                                end
                                if field_state.back_cb.checked then
                                    table.insert(back_indexes, field_state.index)
                                end
                            end
                            if #front_indexes > 0 or #back_indexes > 0 then
                                mapping.models[mid] = {
                                    front_indexes = front_indexes,
                                    back_indexes = back_indexes,
                                }
                            end
                        end
                        if dialog then
                            UIManager:close(dialog)
                        end
                        UIManager:setDirty(nil, "full")
                        if on_done then
                            if mapping.models and next(mapping.models) ~= nil then
                                on_done(true, mapping)
                            else
                                on_done(true, nil)
                            end
                        end
                    end,
                },
            },
        },
    }

    local layout = VerticalGroup:new{
        align = "left",
        title,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        subtitle,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        description,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        content_group,
        VerticalSpan:new{ width = VERTICAL_SPAN_SMALL },
        buttons_row,
    }

    local frame = FrameContainer:new{
        padding = Size.padding.large,
        margin = Size.margin.default,
        radius = Size.radius.window,
        bordersize = Size.border.window,
        background = Blitbuffer.COLOR_WHITE,
        layout,
    }

    dialog = InputContainer:new{}
    dialog.covers_fullscreen = true
    local screen_geom = Geom:new{ x = 0, y = 0, w = screen_width, h = screen_height }
    dialog.dimen = screen_geom

    dialog.cropping_widget = ScrollableContainer:new{
        -- Full-screen scrollable area: no horizontal scrolling because
        -- inner frame is narrower than the screen width.
        dimen = Geom:new{ w = screen_width, h = screen_height },
        show_parent = dialog,
        frame,
    }

    -- Reparent checkbuttons so their visual updates go through the dialog
    for _, state_for_model in pairs(model_state) do
        for _, field_state in ipairs(state_for_model.fields) do
            field_state.front_cb.parent = dialog
            field_state.back_cb.parent = dialog
            field_state.front_cb:initCheckButton(field_state.front_cb.checked)
            field_state.back_cb:initCheckButton(field_state.back_cb.checked)
        end
    end

    dialog[1] = CenterContainer:new{
        dimen = screen_geom,
        dialog.cropping_widget,
    }

    function dialog:paintTo(bb, x, y)
        self.dimen.x = x
        self.dimen.y = y
        -- Full-screen white background so the dialog cleanly covers previous UI,
        -- including under the scrollbars.
        bb:paintRect(x, y, self.dimen.w, self.dimen.h, Blitbuffer.COLOR_WHITE)
        if self[1] then
            self[1]:paintTo(bb, x, y)
        end
    end

    UIManager:show(dialog)
end

function AnkiViewerStudyScreen:refresh()
    UIManager:setDirty(self, function()
        return "ui", self.dimen
    end)
end

function AnkiViewerStudyScreen:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    if self.plugin then
        self.plugin:onScreenClosed()
    end
end

function AnkiViewerStudyScreen:paintTo(bb, x, y)
    self.dimen.x = x
    self.dimen.y = y
    bb:paintRect(x, y, self.dimen.w, self.dimen.h, Blitbuffer.COLOR_WHITE)
    local layout = self.active_layout or self.front_layout
    local content_size = layout:getSize()
    local offset_x = x + math.floor((self.dimen.w - content_size.w) / 2)
    local offset_y = y + math.floor((self.dimen.h - content_size.h) / 2)
    layout:paintTo(bb, offset_x, offset_y)
end

function AnkiViewer:init()
    -- embutido: sem entrada própria no menu (abre pelo Estudar do vocab2deck)
end

function AnkiViewer:ensureSettings()
    if not self.settings_file then
        self.settings_file = DataStorage:getSettingsDir() .. "/ankiviewer.lua"
    end
    if not self.settings then
        self.settings = LuaSettings:open(self.settings_file)
    end
end

function AnkiViewer:readSetting(key, default)
    self:ensureSettings()
    local value = self.settings:readSetting(key)
    if value == nil then
        return default
    end
    return value
end

function AnkiViewer:saveSetting(key, value)
    self:ensureSettings()
    self.settings:saveSetting(key, value)
    self.settings:flush()
end

function AnkiViewer:addToMainMenu(menu_items)
    menu_items.ankiviewer = {
        text = _("Anki Viewer"),
        sorting_hint = "tools",
        callback = function()
            self:showLocalStudy()
        end,
    }
end

function AnkiViewer:importLocalApkg()
    local files = AnkiApkgImport.listApkgFiles()
    if not files or #files == 0 then
        local msg = InfoMessage:new{
            text = _("No .apkg files found. Please place .apkg files in the 'ankiviewer/shared' data folder."),
            timeout = 6,
            show_icon = true,
        }
        UIManager:show(msg)
        return
    end

    local items = {}
    for i, file in ipairs(files) do
        table.insert(items, {
            text = file.name,
            file = file,
            callback = function(menu)
                if menu then
                    UIManager:close(menu)
                end

                local analyzing = InfoMessage:new{
                    text = string.format(_("Analyzing %s…"), file.name),
                    timeout = 0,
                }
                UIManager:show(analyzing)

                local ok_pcall, ok_inspect, inspect_payload = pcall(AnkiApkgImport.inspectApkg, file.path)
                UIManager:close(analyzing)

                if not ok_pcall then
                    local msg = InfoMessage:new{
                        text = _("Failed to analyze .apkg: ") .. tostring(ok_inspect or "Lua error"),
                        timeout = 8,
                        show_icon = true,
                    }
                    UIManager:show(msg)
                    return
                end

                if not ok_inspect then
                    local err_text = inspect_payload or "Unknown error"
                    local msg = InfoMessage:new{
                        text = _("Failed to analyze .apkg: ") .. tostring(err_text),
                        timeout = 8,
                        show_icon = true,
                    }
                    UIManager:show(msg)
                    return
                end

                local inspect_info = inspect_payload or {}
                local short_name = inspect_info.short_name or file.name
                saveInspectInfoForKey(short_name, inspect_info)
                local existing_mapping = loadFieldMappingForShortName(short_name)

                self:showApkgFieldMappingDialog(file, inspect_info, existing_mapping, function(apply, mapping)
                    if not apply then
                        return
                    end
                    if mapping and short_name and short_name ~= "" then
                        mapping.short_name = short_name
                        saveFieldMappingForShortName(short_name, mapping)
                    end
                    self:_chooseImportMode(short_name, function(merge_opts)
                        self:_performApkgImport(file, mapping, merge_opts)
                    end)
                end)
            end,
        })
    end

    local screen = Device.screen
    local plugin = self
    local menu = Menu:new{
        title = _("Select .apkg to import"),
        item_table = items,
        covers_fullscreen = true,
        width = math.floor(screen:getWidth() * 0.9),
        height = math.floor(screen:getHeight() * 0.9),
    }
    function menu:onMenuHold(item)
        local f = item and item.file
        if not f or not f.path then
            return true
        end

        local display_name = f.name or f.path
        UIManager:show(ConfirmBox:new{
            text = string.format(_("Delete file \"%s\"?"), display_name),
            ok_text = _("Delete"),
            cancel_text = _("Cancel"),
            ok_callback = function()
                local ok_remove, err = os.remove(f.path)
                if not ok_remove then
                    local msg = InfoMessage:new{
                        text = _("Failed to delete file: ") .. tostring(err or _("Unknown error")),
                        timeout = 6,
                        show_icon = true,
                    }
                    UIManager:show(msg)
                    return
                end

                local msg = InfoMessage:new{
                    text = _("Deleted file: ") .. display_name,
                    timeout = 4,
                    show_icon = true,
                }
                UIManager:show(msg)

                UIManager:close(self)
                if plugin and plugin.importLocalApkg then
                    plugin:importLocalApkg()
                end
            end,
        })
        return true
    end
    UIManager:show(menu)
end

function AnkiViewer:showHome()
    if self.screen then
        return
    end
    self.screen = AnkiViewerScreen:new{
        plugin = self,
    }
    UIManager:show(self.screen)
end

function AnkiViewer:openLocalStudyFromHome(home_screen)
    UIManager:close(home_screen)
    UIManager:setDirty(nil, "full")
    self.screen = nil
    self:showLocalStudy()
end

function AnkiViewer:showLocalStudy()
    if self.screen then
        return
    end
    self.screen = AnkiViewerStudyScreen:new{
        plugin = self,
    }
    UIManager:show(self.screen)
end

function AnkiViewer:onScreenClosed()
    self.screen = nil
end

-- Embutido no vocab2deck ----------------------------------------------------------
-- O Início do vocab2deck lista os baralhos e as Configurações dele mostram as
-- opções de estudo; estas funções fazem o que antes ficava nos botões Decks e
-- Settings da tela de estudo (mesmo código, chamado de fora).
-- Ganchos que o vocab2deck preenche: on_back, on_close_all, on_decks_changed.

function AnkiViewer:decksChanged()
    if self.on_decks_changed then self.on_decks_changed() end
end

-- Abre a tela de estudo num baralho (nil = o último usado, como antes).
function AnkiViewer:openDeck(deck_id)
    if deck_id then self:saveSetting("last_deck_id", deck_id) end
    if self.screen and self.screen.onClose then self.screen:onClose() end
    self:showLocalStudy()
end

-- Apaga um baralho e o mapeamento guardado dele (o que Decks ▸ toque longo fazia).
function AnkiViewer:deleteDeck(deck_id, deck_name)
    local ok_call, result_or_err = pcall(AnkiDB.deleteDeck, deck_id)
    if not ok_call or not result_or_err then
        error(_("Não foi possível apagar o baralho: ") .. tostring(not ok_call and result_or_err or _("erro desconhecido")), 0)
    end
    clearDeckMetadataForShortName(deck_name)
    if tonumber(self:readSetting("last_deck_id")) == deck_id then
        self:saveSetting("last_deck_id", nil)
    end
    self:decksChanged()
end

-- Field mapping de um baralho importado (o que Settings ▸ Field mapping fazia).
function AnkiViewer:openDeckFieldMapping(deck)
    self:openCurrentDeckFieldMapping({ deck_id = deck.id, deck_name = deck.name })
end

return AnkiViewer
